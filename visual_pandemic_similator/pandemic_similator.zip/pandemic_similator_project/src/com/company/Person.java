package com.company;

import java.util.Random;

public class Person {
    private int x;
    private int y;
    private boolean enfected;
    private boolean in_hospital = false;
    private final double speed ;
    private boolean alive = true;
    private int mask_status = 0;


    public Person(int x, int y, int speed) {
        this.x = x;
        this.y = y;
        this.speed = speed;
        Random random = new Random();

        //chose infected or not
        if (random.nextInt(3) == 1) {
            Infect_person();
        }

        //chose mask type
        if (random.nextInt(5) == 1) {
            mask_status = 1;
        }
    }


    /**
     * getter for x position
     * */
    public int getX() {
        return x;
    }


    /**
     * getter for y position
     * */
    public int getY() {
        return y;
    }

    /**
     * randomly move person any direction
     * */
    public void rand_go(int max_width, int max_height) {
        Random random = new Random();
        int direction = random.nextInt(8);

        if (0 == direction) {
            y -= speed;
            if (y == 0) {
                y += speed;
            }
        }
        if (1 == direction) {
            y -= speed;
            x += speed;
            if (y == 0) {
                y += speed;
            }
            if (x == max_height) {
                x -= speed;
            }
        }
        if (2 == direction) {
            x += speed;
            if (x == max_height) {
                x -= speed;
            }
        }
        if (3 == direction) {
            x += speed;
            y += speed;
            if (x == max_height) {
                x -= speed;
            }
            if (y == max_width) {
                y -= speed;
            }
        }

        if (4 == direction) {
            y += speed;
            if (y == max_width) {
                y -= speed;
            }
        }
        if (5 == direction) {
            x -= speed;
            y += speed;
            if (x == 0) {
                x += speed;
            }
            if (y == max_width) {
                y -= speed;
            }
        }
        if (6 == direction) {
            x -= speed;
            if (x == 0) {
                x += speed;
            }
        }
        if (7 == direction) {
            x -= speed;
            y -= speed;
            if (y == 0) {
                y += speed;
            }
            if (x == 0) {
                x += speed;
            }

        }

    }


    /**
     * it get a person and return distance between this two person
     * */
    public double find_distance(Person p) {
        return Math.sqrt((Math.pow((p.x - this.x), 2)) + Math.pow(p.y - this.y, 2));
    }



    public boolean isInflected() {
        return enfected;
    }

    public boolean isIn_hospital() {
        return in_hospital;
    }

    public void go_hospital() {
        in_hospital = true;
    }

    public void Infect_person() {
        enfected = true;
    }

    public void heal() {
        enfected = false;
        in_hospital = false;
    }

    public boolean Is_alive() {
        return alive;
    }

    /**
     * if mask status 1 return 0.2 else return 1
     * */
    public double mask_value() {
        if (0 == mask_status) {
            return 0.2;
        } else {
            return 1.0;
        }
    }

    public void kill() {
        alive = false;
    }

}
