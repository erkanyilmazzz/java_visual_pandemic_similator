package com.company;

import java.awt.*;

public class My_canvas extends Canvas {

    private Population population;
    private Mediator mediator;
    private long start_time;
    private int p;

    private int state;

    /**
     * Constructs a new Canvas.
     */
    public My_canvas(int size_of_population, int speed_of_people) {
        p = size_of_population;
        population = new Population(p, speed_of_people);
        state = 1;
    }

    /**
     * Paints this canvas.
     * <p>
     * Most applications that subclass {@code Canvas} should
     * override this method in order to perform some useful operation
     * (typically, custom painting of the canvas).
     * The default operation is simply to clear the canvas.
     * Applications that override this method need not call
     * super.paint(g).
     *
     * @param g the specified Graphics context
     * @see #update(Graphics)
     * @see Component#paint(Graphics)
     */
    @Override
    public void paint(Graphics g) {

        for (int i = 0; i < p; ++i) {
            g.setColor(Color.BLACK);
            if (population.at_index(i).isInflected()) {
                g.setColor(Color.RED);
            }
            if (population.at_index(i).Is_alive() && !population.at_index(i).isIn_hospital()) {
                g.fillRect(population.at_index(i).getX(), population.at_index(i).getY(), 5, 5);
            }
            population.at_index(i).rand_go(1000, 600);
            mediator.spread_virus(population.at_index(i));
        }
        try {
            Thread.sleep(50);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (state != 1) {
            this.repaint();
            System.out.println("people counter: " + p
                    + "\tinfected counter: " + mediator.get_infected_count()
                    + "\thospital counter: " + mediator.get_hospital_count()
                    + "\tdead people counter: " + mediator.get_dead_people_count()
                    + "\ttime is " + ((System.currentTimeMillis() - start_time) / 1000)
            );

            if (0==mediator.get_infected_count() && 0==mediator.get_hospital_count()){
                System.out.println("program ended");
                System.exit(0);
            }
        }

    }


    public void pause_canvas() {
        state = 1;
    }

    public void start_canvas() {
        state = 0;
        this.paint(this.getGraphics());
    }

    public void set_canvas(int size_of_population, int speed_of_people, double spreading_factor, double mortal_rate) {
        p = size_of_population;
        population = new Population(p, speed_of_people);
        mediator = new Mediator(size_of_population, spreading_factor, mortal_rate);
        for (int i = 0; i < p; ++i) {
            mediator.add_person(population.at_index(i));
            if (population.at_index(i).isInflected()) {
                mediator.make_person_ill(population.at_index(i));
            }
        }
        state = 1;
        mediator.healer_start();
        start_time = System.currentTimeMillis();
    }

}
