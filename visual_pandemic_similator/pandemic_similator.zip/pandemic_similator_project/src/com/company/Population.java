package com.company;

import java.util.Random;

public class Population {
    private final Person[] persons;

    public Population(int size_of_population,int speed_of_people) {
        persons = new Person[size_of_population];
        for (int i = 0;i<size_of_population;++i ){
            Random random =new Random();
            persons[i]=new Person(random.nextInt(1000),random.nextInt(600),speed_of_people);
        }

    }

    public Person at_index(int index){
        return persons[index];
    }

}
