package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Window extends JFrame {
    private  int population_size;
    private  int speed_of_people;
    private  double spreading_factor;
    private double mortal_rate;


    private final String title;
    private My_canvas canvas;
    private JPanel panel;
    private JButton continueButton;
    private JButton button3;
    private JButton button4;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;

    public Window(String title) {
        super(title);
        System.out.println("Initialization Window...");

        this.title = title;
        setLayout(new FlowLayout());

        createWindow();
        button3.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("start");
            }
        });
        button4.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("pause");
                canvas.pause_canvas();
            }
        });
        button3.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                canvas.set_canvas(population_size,speed_of_people, spreading_factor,mortal_rate);
                canvas.start_canvas();


                System.out.println(population_size);
                System.out.println(speed_of_people);
                System.out.println(spreading_factor);
                System.out.println(mortal_rate);

            }
        });


        textField1.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                population_size =Integer.parseInt(textField1.getText());
                if (population_size<0){
                    System.out.println("please enter  proper value");
                    System.exit(-1);
                }
            }
        });


        textField2.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                speed_of_people =Integer.parseInt(textField2.getText());
                if (speed_of_people<0 || speed_of_people>5){
                    System.out.println("please enter  proper value");
                    System.exit(-1);
                }
            }
        });


        textField3.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                spreading_factor =Double.parseDouble(textField3.getText());
                if (spreading_factor <0.5|| spreading_factor >1.){
                    System.out.println("please enter  proper value");
                    System.exit(-1);
                }
            }
        });
        textField4.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                mortal_rate =Double.parseDouble(textField4.getText());
                if (mortal_rate<0.1|| mortal_rate >0.9){
                    System.out.println("please enter  proper value");
                    System.exit(-1);
                }
            }
        });
        continueButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                canvas.start_canvas();


                System.out.println(population_size);
                System.out.println(speed_of_people);
                System.out.println(spreading_factor);
                System.out.println(mortal_rate);
            }
        });
    }

    private void createWindow() {


        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);


        canvas = new My_canvas(population_size,speed_of_people);
        canvas.setPreferredSize(new Dimension(1000, 600));
        canvas.setMaximumSize(new Dimension(1000, 600));
        canvas.setMinimumSize(new Dimension(1000, 600));
        this.setResizable(false);
        canvas.setFocusable(false);

        add(canvas);
        System.out.println(this.getSize());
        this.setSize(1000, 10000);
        System.out.println(this.getSize());

        add(panel);
        pack();


    }

}
