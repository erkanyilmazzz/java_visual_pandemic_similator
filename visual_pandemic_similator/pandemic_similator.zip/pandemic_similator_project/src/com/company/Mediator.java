package com.company;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Mediator {
    private final BlockingQueue hospital ;
    private  final BlockingQueue infected_people = new ArrayBlockingQueue<Person>(1000000);
    private  final BlockingQueue dead_people =new ArrayBlockingQueue<Person>(100000000);

    private final List<Person> population;
    private final double min_distance = 9.;
    private final double spreading_factor;
    private final double mortal_rate;
    private  final double ventilator_per_people =100 ;


    public Mediator(int size_of_population, double spreading_factor, double mortal_rate) {
        this.spreading_factor = spreading_factor;
        this.mortal_rate =mortal_rate;
        hospital =new ArrayBlockingQueue<Person>((int) (size_of_population/ventilator_per_people));
        population = new ArrayList<>();
    }

    /**
     * `probability` should be given as a percentage, such as
     * 10.0 (10.0%) or 25.5 (25.5%). As an example, if `probability`
     * is 60% (60.0), 100 calls to this function should return ~60
     * `true` values.
     * (Note that Math.random returns a value >= 0.0 and < 1.0.)
     */
    private static boolean getRandomBoolean(float probability) {
        double randomValue = Math.random() * 100;  //0.0 to 99.9
        return randomValue <= probability;
    }


    /**
     * add new person to mediator
     * */
    public void add_person(Person p) {
        population.add(p);
    }


    /**
     * spread virus for Person p
     * */
    public void spread_virus(Person p) {
        if (p.isInflected()) {
            for (Person i : population) {
                double distance = p.find_distance(i);
                if (distance != 0 && distance < min_distance && !i.isIn_hospital()) {

                    Thread t = new Thread(() -> {
                        int c = 0;
                        double dis;
                        double final_dis = 0.;
                        try {
                            Thread.sleep(1000);
                            dis = p.find_distance(i);
                            if (dis != 0 && dis < min_distance && !i.isIn_hospital()) {
                                final_dis = p.find_distance(i);
                                c = 1;
                            }
                            Thread.sleep(1000);
                            dis = p.find_distance(i);
                            if (dis != 0 && dis < min_distance && !i.isIn_hospital()) {
                                final_dis = p.find_distance(i);
                                c = 2;

                            }
                            Thread.sleep(1000);
                            dis = p.find_distance(i);
                            if (dis != 0 && dis < min_distance && !i.isIn_hospital()) {
                                final_dis = p.find_distance(i);
                                c = 3;
                            }
                            Thread.sleep(1000);
                            dis = p.find_distance(i);
                            if (dis != 0 && dis < min_distance && !i.isIn_hospital()) {
                                final_dis = p.find_distance(i);
                                c = 4;
                            }
                            Thread.sleep(1000);
                            dis = p.find_distance(i);
                            if (dis != 0 && dis < min_distance && !i.isIn_hospital()) {
                                final_dis = p.find_distance(i);
                                c = 5;
                            }
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if (final_dis != 0 && final_dis < min_distance && !i.isIn_hospital()) {
                            if (!i.isInflected()) {

                                //= R * (1+C/10) * M_1 * M_2 * (1-D/10)
                                double probability;
                                probability = spreading_factor * ((1 + c) / 10.)
                                        * p.mask_value() * i.mask_value() *
                                        (1 - final_dis / 10.);
                                probability = probability * 1000;
                                probability=Math.min(probability,1);

                                if (getRandomBoolean((float) probability)) {
                                    this.make_person_ill(i);
                                }

                            }
                        }

                    });
                    t.start();


                }
            }
        }
    }


    /**
     * make ill person p
     * */
    public void make_person_ill(Person p) {


        Thread t = new Thread(() -> {
                p.Infect_person();
                Thread t1=new Thread(()->//for dead
                {
                    try {
                        //System.out.println(1000*(long)(100*(1-mortal_rate)));
                        Thread.sleep(1000*(long)(100*(1-mortal_rate)));
                        //Thread.sleep(1000);

                        if (infected_people.contains(p) &&!dead_people.contains(p)){
                            p.kill();
                            dead_people.put(p);

                            p.heal();
                        }

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                });
                t1.start();

                try {
                    infected_people.put(p);
                    Thread.sleep(25000);//wait for go to hospital

                    hospital.put(p);
                    p.go_hospital();

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

        }
        );



        t.start();
    }


    /**
     * find infected person (25 in sec) and try to heal it
     * */
    private void healer() {
        Thread healer_thread = new Thread(() -> {

            while (true) {
                try {

                    Person p = (Person) hospital.take();
                    if (p.Is_alive()){

                        Thread.sleep(10000);//keep people in hospital

                        if (p.Is_alive()){
                            p.heal();
                            infected_people.take();
                        }if (!p.Is_alive()){
                            //dead in hospital
                        }

                    }
                    if(!p.Is_alive()){
                        //gather dead person
                        infected_people.take();
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }
        );

        healer_thread.start();

    }


    /**
     * start po/ventilator counter healers
     * */
    public void healer_start(){
        for (int i=0;i<population.size()/(int )ventilator_per_people;++i){
            this.healer();
        }
    }

    public int get_hospital_count(){
        return hospital.size();
    }
    public int get_infected_count(){
        return infected_people.size();
    }
    public int get_dead_people_count(){
        return dead_people.size();
    }

}
